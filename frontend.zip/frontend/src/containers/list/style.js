import styled from "styled-components";

export const StyledList = styled.div`
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    gap: 0.5rem;

    li {
        display: flex;
        justify-content: center;
        align-items: center;
        flex-direction: row;
        gap: 0.5rem;

        button {
            background-color: #000;
            color: #DF0000;
            border: none;
            border-radius: 2px;
            padding: 2px;
            cursor: pointer;
        }
    }
`